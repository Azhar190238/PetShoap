import ServiceCard from "../ServicePuppies/ServiceCard";
import Banner from "./Banner";


const ServicesPupies = () => {
    return (
        <div>
            <Banner></Banner>
            <ServiceCard></ServiceCard>
            
            

        </div>
    );
};

export default ServicesPupies;