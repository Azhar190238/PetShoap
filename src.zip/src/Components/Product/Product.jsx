import Banner from "./Banner";
import Card from "./Card";

const Product = () => {
    return (
        <div className="">
           <Banner></Banner> 
           <Card></Card>
        </div>
    );
};

export default Product;