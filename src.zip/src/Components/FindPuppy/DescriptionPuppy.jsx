import React from 'react';

const DescriptionPuppy = () => {
    return (
        <div>
            
        </div>
    );
};

export default DescriptionPuppy;