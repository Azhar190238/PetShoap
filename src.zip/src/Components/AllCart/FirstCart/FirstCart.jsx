import React from 'react';
import Banner from '../Banner';
import TableCart from './TableCart';

const FirstCart = () => {
    return (
        <div className=''>
            <Banner></Banner>
            <TableCart></TableCart> 
        </div>
    );
};

export default FirstCart;