import React from 'react';
import Banner from '../Banner';
import ProcessCard from './ProcessCard';

const ProcessPayment = () => {
    return (
        <div>
            <Banner></Banner>
            <ProcessCard></ProcessCard>
        </div>
    );
};

export default ProcessPayment;