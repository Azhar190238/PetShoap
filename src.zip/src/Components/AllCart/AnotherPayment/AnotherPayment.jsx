import React from 'react';
import Banner from '../Banner';
import AnotherCart from './AnotherCart';

const AnotherPayment = () => {
    return (
        <div>
            <Banner></Banner>
            <AnotherCart></AnotherCart>
        </div>
    );
};

export default AnotherPayment;