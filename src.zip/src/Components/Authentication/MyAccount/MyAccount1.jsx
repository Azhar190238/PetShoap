import React from 'react';
import Banner from '../../AllCart/Banner';
import AccountForm from './AccountForm';

const MyAccount1 = () => {
    return (
        <div>
            <Banner></Banner>
            <AccountForm></AccountForm>
        </div>
    );
};

export default MyAccount1;